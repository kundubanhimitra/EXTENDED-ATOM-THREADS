/*
 * ExceptionGeneration.h
 *
 *  Created on: 02-Feb-2021
 *      Author: banhimitra
 */

#ifndef EXCEPTIONGENERATION_H_
#define EXCEPTIONGENERATION_H_

void GenerateMemUsageException();
void GenerateDivBy0Exception();
void GenerateBusFaultException();



#endif /* EXCEPTIONGENERATION_H_ */
