/*
 * board.h
 *
 *  Created on: 01-June-2020
 *      Author: J.Shankarappa
 */

#ifndef __BOARD_H_
#define __BOARD_H_

#include <stdint.h>
#include <inc/tm4c123gh6pm.h>

#include "uart0.h"

#define  SW1        (GPIO_PORTF_DATA_R&(1<<4))
#define  SW2        (GPIO_PORTF_DATA_R&(1<<0))

#define  LED_RED    0x02
#define  LED_BLUE   0x04
#define  LED_GREEN  0x08

int setup_board(void);
void setup_systick(void);
void setup_clock(void);
void setup_led(void);
void toggle_led(uint8_t color);

#endif /* __BOARD_H_ */
