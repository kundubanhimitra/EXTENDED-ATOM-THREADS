/*
 * main.c
 *
 *  Created on: 25-May-2020
 *      Author: J.Shankarappa
 */

#include <stdio.h>
#include "atomport-private.h"
#include "atom.h"
#include "atomtimer.h"
#include "board.h"
#include "atompipe.h"
#include "ExceptionGeneration.h"
#include "atompipe.h"
#include "atomport.h"


void gpiof_isr(void);
/* Constants */

/*
 * Idle thread stack size
 *
 * This needs to be large enough to handle any interrupt handlers
 * and callbacks called by interrupt handlers (e.g. user-created
 * timer callbacks) as well as the saving of all context when
 * switching away from this thread.
 *
 * In this case, the idle stack is allocated on the BSS via the
 * idle_thread_stack[] byte array.
 */
#define IDLE_STACK_SIZE_BYTES       512

/*
 * Main thread stack size
 *
 * The Main thread stack generally needs to be larger than the idle
 * thread stack, as not only does it need to store interrupt handler
 * stack saves and context switch saves, but the application main thread
 * will generally be carrying out more nested function calls and require
 * stack for application code local variables etc.
 *
 */
#define MAIN_STACK_SIZE_BYTES       1024

/* Default thread priority */
#define MAIN_THREAD_PRIO            16

/* Application threads' TCBs */
static ATOM_TCB main_tcb;
static ATOM_TCB periodic_task_tcb1;
static ATOM_TCB periodic_task_tcb2;


/* Main thread's stack area */
static uint8_t main_thread_stack[MAIN_STACK_SIZE_BYTES];

static uint8_t periodic_task_stack1[MAIN_STACK_SIZE_BYTES];
static uint8_t periodic_task_stack2[MAIN_STACK_SIZE_BYTES];

/* Idle thread's stack area */
static uint8_t idle_thread_stack[IDLE_STACK_SIZE_BYTES];

/* Forward declarations */
static void main_thread_func(uint32_t data);

static void periodic_task1(uint32_t data);
static  void periodic_task2(uint32_t data);
/**
 * main - Program entry point.
 *
 * Sets up the TM4C123GXL hardware resources (system tick timer interrupt) necessary
 * for the OS to be started. Creates an application thread and starts the OS.
 *
 */
ATOM_PIPE pipeid,pipeid2;
#define SIZE_OF_EACH_QUEUE_MESSAGE 2
#define TOTAL_PIPE_SPACE 32
#define NUM_MSGS_QUEUE 10
uint8_t message1[SIZE_OF_EACH_QUEUE_MESSAGE],message2[SIZE_OF_EACH_QUEUE_MESSAGE];
uint8_t pipespace[TOTAL_PIPE_SPACE];
uint8_t pipespace2[TOTAL_PIPE_SPACE];

uint8_t data_from_isr[3]={0};
uint8_t task_exception=0;
int main(void)
{
    int8_t status;
    uint32_t loop;

    /*
     * Brief delay to give the debugger a chance to stop the core before we
     * muck around with the chip's configuration.
     */
    for(loop = 0; loop < 1000000; ++loop) {
        __asm__("nop");
    }

    /**
     * Note: to protect OS structures and data during initialisation,
     * interrupts must remain disabled until the first thread
     * has been restored. They are re-enabled at the very end of
     * the first thread restore, at which point it is safe for a
     * reschedule to take place.
     */

    setup_board();

    //SW SWITCH INTERRUPTS
    GPIO_PORTF_LOCK_R= 0x4C4F434B;
    status = GPIO_PORTF_LOCK_R;
    GPIO_PORTF_CR_R |= 0x11;
    GPIO_PORTF_PUR_R|= 0x11;
    GPIO_PORTF_DIR_R &= 0xEE;
    GPIO_PORTF_DR8R_R|=0x11;
    GPIO_PORTF_DEN_R = 0x1F;
    GPIO_PORTF_LOCK_R= 0xFFFFFFFF;
    GPIO_PORTF_ICR_R = 0x11;
    GPIO_PORTF_IM_R |= 0x11;
    NVIC_EN0_R |= 0x40000000;


    /*
     * Initialise the OS before creating our threads.
     *
     */
    status = atomOSInit(&idle_thread_stack[0], IDLE_STACK_SIZE_BYTES, FALSE);

    if(status == ATOM_OK) {

        /* Create an application thread */
       status = atomThreadCreate( &main_tcb,
                                   MAIN_THREAD_PRIO,
                                   main_thread_func,
                                   0,
                                   &main_thread_stack[0],
                                   MAIN_STACK_SIZE_BYTES,
                                   TRUE
                                  );

        /* Create an application thread */
      status = atomThreadCreate( &periodic_task_tcb1,
                                   MAIN_THREAD_PRIO,
                                   periodic_task1,
                                   0,
                                   &periodic_task_stack1[0],
                                   MAIN_STACK_SIZE_BYTES,
                                   TRUE
                                  );
       status = atomThreadCreate( &periodic_task_tcb2,
                                   MAIN_THREAD_PRIO,
                                   periodic_task2,
                                   0,
                                   &periodic_task_stack2[0],
                                   MAIN_STACK_SIZE_BYTES,
                                   TRUE
                                  );
      /* status = atomThreadCreate( &debug_task_tcb,
                                          MAIN_THREAD_PRIO,
                                          debugtask,
                                          0,
                                          &debug_task_stack[0],
                                          MAIN_STACK_SIZE_BYTES,
                                          TRUE
                                         );*/

        atomPipeCreate (&pipeid,&pipespace, 1, 10);
        atomPipeCreate (&pipeid2,&pipespace2, 1, 10);

        if(status == ATOM_OK) {
            /**
             * First application thread successfully created. It is
             * now possible to start the OS. Execution will not return
             * from atomOSStart(), which will restore the context of
             * our application thread and start executing it.
             *
             * Note that interrupts are still disabled at this point.
             * They will be enabled as we restore and execute our first
             * thread in archFirstThreadRestore().
             */
            atomOSStart();
        }
    }

    while(1) {
        ;
    }

    /* There was an error starting the OS if we reach here */
    return (0);
}

/**
 * main_thread_func
 *
 * Entry point for main application thread.
 *
 * This is the first thread that will be executed when the OS is started.
 *
 * param[in]: data Unused (optional thread entry parameter)
 *
 * return: None
 */

static void main_thread_func(uint32_t data __maybe_unused)
{
    uint32_t countthisthread = 8,status;
    volatile int delaycount=100000;
    ATOM_TCB *task_ptr;
    char pipedatarx1[3]={0xEE,0xEE,0xEE};
    /* Put a message out on the UART */
   // printf("\nTASK STARTED\n");
    GPIO_PORTF_DATA_R = LED_GREEN;
    for(delaycount=0;delaycount<30000000;delaycount++);
    toggle_led(LED_GREEN);
   // GenerateBusFaultException();
    while(1) {
        /* Toggle a LED (ek-tm4c123gxl specific) */
        //toggle_led(LED_RED);
    //    atomQueueGet (&queueid, 0,message2);
        countthisthread--;
       // printf("\nCount Value = %d",countthisthread);

        //atomPipeGet(&pipeid2,pipedatarx1,3,-1);
        //if(pipedatarx1[0]!=pipedatarx1[1])
        if(task_exception==1)
        {
            task_exception=0;
            GPIO_PORTF_DATA_R = LED_RED;
           //status = atomTimerDelay( MS_TO_TICKS(5000));
           for(delaycount=0;delaycount<10000000;delaycount++);
           GenerateBusFaultException();
           toggle_led(LED_RED);
        }




       /* if(countthisthread ==0)
        {
            GPIO_PORTF_DATA_R = LED_BLUE;
           //status = atomTimerDelay( MS_TO_TICKS(5000));
           for(delaycount=0;delaycount<10000000;delaycount++);
          // GenerateBusFaultException();
           toggle_led(LED_BLUE);
           //GenerateDivBy0Exception();
        }*/
        //GetExceptionFlag();
       /* if(GetExceptionFlag() == 1)
        {
            //AddToExceptionTaskList (ATOM_TCB *tcb_ptr)
            //{
                CRITICAL_STORE;
                CRITICAL_START ();
                task_ptr = atomCurrentContext();
                //atomThreadSuspend (task_ptr);

             //   AddToExceptionTaskList(task_ptr);

                CRITICAL_END ();
            //}
            while(1); //Wait For Systick Handler
        }*/
        /*
        GPIO_PORTF_DATA_R = LED_RED;
        if(message2[0]==0)
            GPIO_PORTF_DATA_R = LED_GREEN;
        if(message2[1]==0)
            GPIO_PORTF_DATA_R = LED_BLUE;
        //printf("%d\n%d\n",SW2,SW1);

        message2[0]=0;
        message2[1]=0;
        */
     //   for(delaycount=0;delaycount<10000000;delaycount++);
       status = atomTimerDelay( MS_TO_TICKS(1000));
       toggle_led(LED_BLUE);//;GPIO_PORTF_DATA_R = LED_RED;
      // printf("\n\%d\n",status);
       }
}


uint8_t prevstatesw1 , prevstatesw2;

ATOM_TIMER timer_periodic_task1;
uint8_t thread_suspended;
static void periodic_task1(uint32_t data __maybe_unused)
{
    int i=0,debounce = 0,count=0;
    volatile int delaycount=100000;

    char pipedatatx[3]={0xAA,0xBB,0xCC};
    char pipedatarx[3]={0xEE,0xEE,0xEE};
    thread_suspended=0;
    while(1)
    {
        pipedatarx[0]=0xEE;
        pipedatarx[1]=0xEE;
        pipedatarx[2]=0xEE;
       // atomPipePut(&pipeid,pipedatatx,3,-1);
        atomTimerDelay( MS_TO_TICKS(1000));
        atomPipeGet(&pipeid,pipedatarx,3,-1);
        if(pipedatarx[0]!=pipedatarx[1])
        {
            printf("\nTASK1 RECEIVED %d %d %d",pipedatarx[0],pipedatarx[1],pipedatarx[2]);
            if(thread_suspended==1)
            {
                atomThreadResume(&periodic_task_tcb2);
                thread_suspended=0;
            }
            else
            {
                atomThreadSuspend(&periodic_task_tcb2);
                thread_suspended=1;
            }
        }
        /*if(count == 8)
           atomThreadSuspend(&periodic_task_tcb2);
        if(count==16)
           atomThreadResume(&periodic_task_tcb2);*/
       // atomTimerDelayBanhi( MS_TO_TICKS(1000),&timer_periodic_task1);
     // for(delaycount=0;delaycount<1000000;delaycount++);
       // delaycount=1000000;
        count++;
        printf("\nTASK1");


    }
    /*uint8_t currstatesw1,prevstatesw1,currstatesw2,prevstatesw2;
    prevstatesw1 = currstatesw1 = SW1;
    prevstatesw2 =currstatesw2= SW2;
    while(1) {
       // printf("%d\n%d\n",SW2,SW1);
        message1[0] = 1;
        message1[1] = 1;
        debounce = 0;
        currstatesw1=SW1;//0xAA;//SW1;
        if(prevstatesw1!=currstatesw1)
        {
            for(i=0;i<10000;i++)//delay to check the debouce time approx 100us
            {
                currstatesw1=SW1;
                if(prevstatesw1==currstatesw1)
                {
                    debounce=1;
                    break;

                }

            }


        }
        if(debounce == 0)
        {
            message1[0] = currstatesw1;
            prevstatesw1=currstatesw1;
        }

        debounce = 0;
        currstatesw2=SW2;//0xAA;//SW1;
        if(prevstatesw1!=currstatesw1)
        {
            for(i=0;i<10000;i++)//delay to check the debouce time approx 100us
            {
                currstatesw2=SW2;
                if(prevstatesw2==currstatesw2)
                {
                    debounce=1;
                    break;

                }

            }


        }
        if(debounce == 0)
        {
            message1[1] = currstatesw2;
            prevstatesw2=currstatesw2;
        }

     //   atomQueuePut (&queueid, 0,message1);
    //    atomTimerDelay( MS_TO_TICKS(30) );

    }*/
}

ATOM_TIMER timer_periodic_task2;
static void periodic_task2(uint32_t data __maybe_unused)
{
    int i=0,debounce = 0;
    volatile int delaycount=100000;
    char pipedatarx[3]={0xEE,0xEE,0xEE};

        while(1)
        {
           // atomTimerDelayBanhi( MS_TO_TICKS(1000),&timer_periodic_task2);
         //   for(delaycount=0;delaycount<1000000;delaycount++);
            //atomPipeGet(&pipeid,pipedatarx,3,-1);

           // printf("\nTASK 2");
           // printf("\n%x %x %x",pipedatarx[0],pipedatarx[1],pipedatarx[2]);
            atomTimerDelay( MS_TO_TICKS(500));
        }
   /*

     uint8_t currstatesw1,prevstatesw1,currstatesw2,prevstatesw2;
    prevstatesw1 = currstatesw1 = SW1;
    prevstatesw2 =currstatesw2= SW2;
    while(1) {
       // printf("%d\n%d\n",SW2,SW1);
        message1[0] = 1;
        message1[1] = 1;
        debounce = 0;
        currstatesw1=SW1;//0xAA;//SW1;
        if(prevstatesw1!=currstatesw1)
        {
            for(i=0;i<10000;i++)//delay to check the debouce time approx 100us
            {
                currstatesw1=SW1;
                if(prevstatesw1==currstatesw1)
                {
                    debounce=1;
                    break;

                }

            }


        }
        if(debounce == 0)
        {
            message1[0] = currstatesw1;
            prevstatesw1=currstatesw1;
        }

        debounce = 0;
        currstatesw2=SW2;//0xAA;//SW1;
        if(prevstatesw1!=currstatesw1)
        {
            for(i=0;i<10000;i++)//delay to check the debouce time approx 100us
            {
                currstatesw2=SW2;
                if(prevstatesw2==currstatesw2)
                {
                    debounce=1;
                    break;

                }

            }


        }
        if(debounce == 0)
        {
            message1[1] = currstatesw2;
            prevstatesw2=currstatesw2;
        }

     //   atomQueuePut (&queueid, 0,message1);
    //    atomTimerDelay( MS_TO_TICKS(30) );

    }
    */
}


/* PortF Interrupt Service Routine */

void gpiof_isr(void)
{
         /* clear PF4 int */
    atomIntEnter();

    /* Must be called at the start of interrupt handler that may call an
       OS primitive and make a thread ready.  */

    if(GPIO_PORTF_MIS_R & 0x10!=0 )
    {
        data_from_isr[0]=atomTimeGet();
        data_from_isr[1]=data_from_isr[0]+1;
        data_from_isr[2]=data_from_isr[0]+2;
        atomPipePut(&pipeid,data_from_isr,3,-1);
    //atomPipePut(&pipeid,data_from_isr,3,-1);
    }
    else
        task_exception=1;


    GPIO_PORTF_ICR_R = 0x11;
    /* Process GPIO Port F Interrupt */
   // toggle_led(LED_GREEN);
    /* Must be called at the end of interrupt handler that may call an
        OS primitive and make a thread ready. */
    atomIntExit(0);
}
