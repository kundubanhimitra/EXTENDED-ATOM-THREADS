/*
 * ExceptionGeneration.c
 *
 *  Created on: 02-Feb-2021
 *      Author: banhimitra
 */


//S_BANHI
#include <stdio.h>
#include "ExceptionGeneration.h"
int trial_data=2;
void GenerateDivBy0Exception()
{
    trial_data=trial_data/0;
}

void GenerateMemUsageException()
{

}

void GenerateBusFaultException()
{
  *(uint32_t *)0xF0002001 = 32;
}

uint32_t *(illegalFunction)(void);
void GenerateIllegalInstruction()
{
   //uint32_t =0xFFFFFFFF;


  *(uint32_t *)0x20002001 = 0xFFFFFFFF;
}
